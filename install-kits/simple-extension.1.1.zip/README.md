Vtiger - Building a simple extension module
==============================

This repo presents a minimalistic structure for a basic extension module for Vtiger.

## Usage ##

This code was made and tested under Vtiger 6.0.0 beta and it will NOT work under 5.4. or earlier.

I have made a [blog post](http://#) on the steps needed to build this module.

## License ##

This code is released under the [Vtiger Public License Version 1.1](https://www.vtiger.com/vtiger-public-license-1-1/ "Vtiger Public License 1.1 (VPL 1.1) ").

